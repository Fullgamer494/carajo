rootProject.name = "api"

dependencyResolutionManagement {
    repositories {
        mavenCentral()
    }
}
